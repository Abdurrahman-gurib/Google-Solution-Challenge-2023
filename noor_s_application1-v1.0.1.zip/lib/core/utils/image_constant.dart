class ImageConstant {
  static String imgRefresh = 'assets/images/img_refresh.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgScreenshot2022 = 'assets/images/img_screenshot2022.png';

  static String imgEllipse8 = 'assets/images/img_ellipse8.png';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgFavpngearthda522x408 =
      'assets/images/img_favpngearthda_522x408.png';

  static String imgFavpngearthda279x279 =
      'assets/images/img_favpngearthda_279x279.png';

  static String imgDannylinesxct = 'assets/images/img_dannylinesxct.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgDannylinesxct852x414 =
      'assets/images/img_dannylinesxct_852x414.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgVector3 = 'assets/images/img_vector3.png';

  static String imgPexelspixabay76969 =
      'assets/images/img_pexelspixabay76969.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgRefreshGray700 = 'assets/images/img_refresh_gray_700.svg';

  static String imgFavpngearthda = 'assets/images/img_favpngearthda.png';

  static String imgArrowleftWhiteA700 =
      'assets/images/img_arrowleft_white_a700.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
