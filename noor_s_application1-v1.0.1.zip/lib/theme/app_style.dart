import 'package:flutter/material.dart';
import 'package:noor_s_application1/core/app_export.dart';

class AppStyle {
  static TextStyle txtAbelRegular26 = TextStyle(
    color: ColorConstant.cyan500,
    fontSize: getFontSize(
      26,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbelRegular17 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold45 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      45,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold12 = TextStyle(
    color: ColorConstant.gray100,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbelRegular10 = TextStyle(
    color: ColorConstant.whiteA7007f,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold45WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      45,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold35 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbelRegular11 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      11,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbelRegular12 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black901,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtAbelRegular35 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      35,
    ),
    fontFamily: 'Abel',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold26 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      26,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold15 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtArialRoundedMTBold16 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Arial Rounded MT Bold',
    fontWeight: FontWeight.w400,
  );
}
