import 'package:noor_s_application1/core/app_export.dart';

class ApiClient extends GetConnect {}
