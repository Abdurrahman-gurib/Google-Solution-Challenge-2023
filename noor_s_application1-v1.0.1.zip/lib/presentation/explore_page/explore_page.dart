import 'controller/explore_controller.dart';
import 'models/explore_model.dart';
import 'package:flutter/material.dart';
import 'package:noor_s_application1/core/app_export.dart';
import 'package:noor_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:noor_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:noor_s_application1/widgets/custom_drop_down.dart';

// ignore_for_file: must_be_immutable
class ExplorePage extends StatelessWidget {
  ExploreController controller = Get.put(ExploreController(ExploreModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.black90001,
            body: Container(
                height: getVerticalSize(766),
                width: getHorizontalSize(408),
                decoration: AppDecoration.fillBlack90001,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                          padding: getPadding(top: 34),
                          child: Text("lbl_spaceexplore".tr,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: AppStyle.txtAbelRegular35))),
                  CustomImageView(
                      svgPath: ImageConstant.imgVector,
                      height: getVerticalSize(6),
                      width: getHorizontalSize(5),
                      alignment: Alignment.bottomCenter,
                      margin: getMargin(bottom: 42)),
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          height: getVerticalSize(766),
                          width: getHorizontalSize(408),
                          child:
                              Stack(alignment: Alignment.topCenter, children: [
                            CustomImageView(
                                imagePath: ImageConstant.imgDannylinesxct,
                                height: getVerticalSize(852),
                                width: getHorizontalSize(408),
                                alignment: Alignment.center),
                            Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                    padding: getPadding(
                                        left: 39, top: 23, right: 29),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          CustomAppBar(
                                              height: getVerticalSize(31),
                                              leadingWidth: 55,
                                              leading: AppbarImage(
                                                  height: getVerticalSize(18),
                                                  width: getHorizontalSize(16),
                                                  svgPath:
                                                      ImageConstant.imgMenu,
                                                  margin: getMargin(
                                                      left: 39,
                                                      top: 5,
                                                      bottom: 7)),
                                              centerTitle: true,
                                              title: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text:
                                                            "lbl_earthquake".tr,
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .whiteA700,
                                                            fontSize:
                                                                getFontSize(26),
                                                            fontFamily:
                                                                'Arial Rounded MT Bold',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400)),
                                                    TextSpan(
                                                        text: "lbl_timeline".tr,
                                                        style: TextStyle(
                                                            color: ColorConstant
                                                                .whiteA700,
                                                            fontSize:
                                                                getFontSize(26),
                                                            fontFamily: 'Abel',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400))
                                                  ]),
                                                  textAlign: TextAlign.left)),
                                          Padding(
                                              padding: getPadding(top: 26),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgArrowleft,
                                                        height:
                                                            getVerticalSize(26),
                                                        width:
                                                            getHorizontalSize(
                                                                34),
                                                        onTap: () {
                                                          onTapImgArrowleft();
                                                        }),
                                                    CustomDropDown(
                                                        width:
                                                            getHorizontalSize(
                                                                78),
                                                        focusNode: FocusNode(),
                                                        icon: Container(
                                                            margin: getMargin(
                                                                left: 3,
                                                                right: 11),
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: ColorConstant
                                                                        .gray400,
                                                                    width:
                                                                        getHorizontalSize(
                                                                            1),
                                                                    strokeAlign:
                                                                        strokeAlignCenter)),
                                                            child: CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgArrowdown)),
                                                        hintText:
                                                            "lbl_start_date".tr,
                                                        margin: getMargin(
                                                            left: 9, bottom: 2),
                                                        items: controller
                                                            .exploreModelObj
                                                            .value
                                                            .dropdownItemList,
                                                        onChanged: (value) {
                                                          controller.onSelected(
                                                              value);
                                                        }),
                                                    CustomDropDown(
                                                        width:
                                                            getHorizontalSize(
                                                                76),
                                                        focusNode: FocusNode(),
                                                        icon: Container(
                                                            margin: getMargin(
                                                                left: 6,
                                                                right: 11),
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: ColorConstant
                                                                        .gray400,
                                                                    width:
                                                                        getHorizontalSize(
                                                                            1),
                                                                    strokeAlign:
                                                                        strokeAlignCenter)),
                                                            child: CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgArrowdown)),
                                                        hintText:
                                                            "lbl_end_date".tr,
                                                        margin: getMargin(
                                                            left: 5, bottom: 2),
                                                        items: controller
                                                            .exploreModelObj
                                                            .value
                                                            .dropdownItemList1,
                                                        onChanged: (value) {
                                                          controller
                                                              .onSelected1(
                                                                  value);
                                                        }),
                                                    CustomDropDown(
                                                        width:
                                                            getHorizontalSize(
                                                                75),
                                                        focusNode: FocusNode(),
                                                        icon: Container(
                                                            margin: getMargin(
                                                                left: 4,
                                                                right: 8),
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    color: ColorConstant
                                                                        .gray400,
                                                                    width:
                                                                        getHorizontalSize(
                                                                            1),
                                                                    strokeAlign:
                                                                        strokeAlignCenter)),
                                                            child: CustomImageView(
                                                                svgPath:
                                                                    ImageConstant
                                                                        .imgArrowdown)),
                                                        hintText:
                                                            "lbl_magnitude".tr,
                                                        margin: getMargin(
                                                            left: 5, bottom: 2),
                                                        items: controller
                                                            .exploreModelObj
                                                            .value
                                                            .dropdownItemList2,
                                                        onChanged: (value) {
                                                          controller
                                                              .onSelected2(
                                                                  value);
                                                        }),
                                                    Container(
                                                        width:
                                                            getHorizontalSize(
                                                                50),
                                                        margin: getMargin(
                                                            left: 3, bottom: 2),
                                                        padding: getPadding(
                                                            left: 19,
                                                            top: 5,
                                                            right: 19,
                                                            bottom: 5),
                                                        decoration: AppDecoration
                                                            .txtFillWhiteA70033
                                                            .copyWith(
                                                                borderRadius:
                                                                    BorderRadiusStyle
                                                                        .txtCircleBorder12),
                                                        child: Text("lbl_go".tr,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            textAlign:
                                                                TextAlign.left,
                                                            style: AppStyle
                                                                .txtAbelRegular10))
                                                  ]))
                                        ])))
                          ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          height: getVerticalSize(450),
                          width: getHorizontalSize(408),
                          child: Stack(alignment: Alignment.center, children: [
                            Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                    height: getVerticalSize(814),
                                    width: getHorizontalSize(408),
                                    margin: getMargin(top: 14),
                                    child: Stack(
                                        alignment: Alignment.topCenter,
                                        children: [
                                          CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgFavpngearthda,
                                              height: getVerticalSize(766),
                                              width: getHorizontalSize(408),
                                              alignment:
                                                  Alignment.bottomCenter),
                                          CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgFavpngearthda522x408,
                                              height: getVerticalSize(522),
                                              width: getHorizontalSize(408),
                                              alignment: Alignment.topCenter)
                                        ]))),
                            CustomImageView(
                                imagePath: ImageConstant.imgEllipse8,
                                height: getVerticalSize(885),
                                width: getHorizontalSize(408),
                                alignment: Alignment.center)
                          ]))),
                  Align(
                      alignment: Alignment.topLeft,
                      child: Padding(
                          padding: getPadding(left: 12, top: 158),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text("lbl_magnitude2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtArialRoundedMTBold35),
                                          Padding(
                                              padding: getPadding(
                                                  left: 12, top: 2, bottom: 4),
                                              child: Text(
                                                  "lbl_richter_scale".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtAbelRegular26))
                                        ])),
                                Container(
                                    width: getHorizontalSize(329),
                                    margin: getMargin(top: 9, right: 2),
                                    child: Text("msg_can_be_detected".tr,
                                        maxLines: null,
                                        textAlign: TextAlign.left,
                                        style: AppStyle.txtAbelRegular11))
                              ])))
                ]))));
  }

  onTapImgArrowleft() {
    Get.back();
  }
}
