import 'controller/home_controller.dart';
import 'models/home_model.dart';
import 'package:flutter/material.dart';
import 'package:noor_s_application1/core/app_export.dart';
import 'package:noor_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:noor_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:noor_s_application1/widgets/custom_button.dart';
import 'package:noor_s_application1/widgets/custom_search_view.dart';

// ignore_for_file: must_be_immutable
class HomePage extends StatelessWidget {
  HomeController controller = Get.put(HomeController(HomeModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.transparent,
        body: Container(
          height: getVerticalSize(
            766,
          ),
          width: double.maxFinite,
          child: Stack(
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: getVerticalSize(
                    766,
                  ),
                  width: double.maxFinite,
                  decoration: AppDecoration.fillBlack90001,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: getPadding(
                            left: 106,
                            top: 34,
                            right: 105,
                            bottom: 42,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "lbl_spaceexplore".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtAbelRegular35,
                              ),
                              Spacer(),
                              Container(
                                height: getSize(
                                  6,
                                ),
                                width: getSize(
                                  6,
                                ),
                                decoration: BoxDecoration(
                                  color: ColorConstant.gray700,
                                  borderRadius: BorderRadius.circular(
                                    getHorizontalSize(
                                      3,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          height: getVerticalSize(
                            865,
                          ),
                          width: double.maxFinite,
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              CustomImageView(
                                imagePath:
                                    ImageConstant.imgDannylinesxct852x414,
                                height: getVerticalSize(
                                  852,
                                ),
                                width: getHorizontalSize(
                                  414,
                                ),
                                alignment: Alignment.center,
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Padding(
                                  padding: getPadding(
                                    left: 40,
                                    top: 23,
                                    right: 43,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      CustomAppBar(
                                        height: getVerticalSize(
                                          31,
                                        ),
                                        leadingWidth: 57,
                                        leading: AppbarImage(
                                          height: getVerticalSize(
                                            18,
                                          ),
                                          width: getHorizontalSize(
                                            17,
                                          ),
                                          svgPath: ImageConstant.imgMenu,
                                          margin: getMargin(
                                            left: 40,
                                            top: 5,
                                            bottom: 7,
                                          ),
                                        ),
                                        centerTitle: true,
                                        title: RichText(
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: "lbl_earthquake".tr,
                                                style: TextStyle(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  fontSize: getFontSize(
                                                    26,
                                                  ),
                                                  fontFamily:
                                                      'Arial Rounded MT Bold',
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                              TextSpan(
                                                text: "lbl_geolocation".tr,
                                                style: TextStyle(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  fontSize: getFontSize(
                                                    26,
                                                  ),
                                                  fontFamily: 'Abel',
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ],
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.centerRight,
                                        child: CustomSearchView(
                                          focusNode: FocusNode(),
                                          controller:
                                              controller.group589Controller,
                                          hintText: "lbl_search_country".tr,
                                          margin: getMargin(
                                            left: 40,
                                            top: 25,
                                            right: 23,
                                          ),
                                          alignment: Alignment.centerRight,
                                          prefix: Container(
                                            margin: getMargin(
                                              left: 21,
                                              top: 7,
                                              right: 14,
                                              bottom: 7,
                                            ),
                                            decoration: BoxDecoration(
                                              color: ColorConstant.whiteA700,
                                            ),
                                            child: CustomImageView(
                                              svgPath: ImageConstant.imgSearch,
                                            ),
                                          ),
                                          prefixConstraints: BoxConstraints(
                                            maxHeight: getVerticalSize(
                                              35,
                                            ),
                                          ),
                                          suffix: Padding(
                                            padding: EdgeInsets.only(
                                              right: getHorizontalSize(
                                                15,
                                              ),
                                            ),
                                            child: IconButton(
                                              onPressed: () {
                                                controller.group589Controller
                                                    .clear();
                                              },
                                              icon: Icon(
                                                Icons.clear,
                                                color: Colors.grey.shade600,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 142,
                                          top: 31,
                                        ),
                                        child: Text(
                                          "lbl_earth".tr,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.left,
                                          style: AppStyle.txtAbelRegular17,
                                        ),
                                      ),
                                      Container(
                                        height: getSize(
                                          323,
                                        ),
                                        width: getSize(
                                          323,
                                        ),
                                        margin: getMargin(
                                          left: 8,
                                          top: 19,
                                        ),
                                        child: Stack(
                                          alignment: Alignment.center,
                                          children: [
                                            Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                height: getVerticalSize(
                                                  279,
                                                ),
                                                width: getHorizontalSize(
                                                  283,
                                                ),
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                        height: getSize(
                                                          279,
                                                        ),
                                                        width: getSize(
                                                          279,
                                                        ),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: ColorConstant
                                                              .teal300,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                            getHorizontalSize(
                                                              139,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    CustomImageView(
                                                      imagePath: ImageConstant
                                                          .imgFavpngearthda279x279,
                                                      height: getSize(
                                                        279,
                                                      ),
                                                      width: getSize(
                                                        279,
                                                      ),
                                                      alignment:
                                                          Alignment.center,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                padding: getPadding(
                                                  left: 20,
                                                  top: 43,
                                                  right: 20,
                                                  bottom: 43,
                                                ),
                                                decoration: AppDecoration
                                                    .outlineWhiteA70033
                                                    .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder161,
                                                ),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    CustomButton(
                                                      height: getVerticalSize(
                                                        40,
                                                      ),
                                                      width: getSize(
                                                        40,
                                                      ),
                                                      text: "lbl_3".tr,
                                                      margin: getMargin(
                                                        right: 36,
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                        width: getSize(
                                                          35,
                                                        ),
                                                        margin: getMargin(
                                                          top: 71,
                                                        ),
                                                        padding: getPadding(
                                                          left: 13,
                                                          top: 7,
                                                          right: 13,
                                                          bottom: 7,
                                                        ),
                                                        decoration: AppDecoration
                                                            .txtFillDeeppurple2007f
                                                            .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .txtRoundedBorder17,
                                                        ),
                                                        child: Text(
                                                          "lbl_1".tr,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          textAlign:
                                                              TextAlign.left,
                                                          style: AppStyle
                                                              .txtArialRoundedMTBold16,
                                                        ),
                                                      ),
                                                    ),
                                                    CustomButton(
                                                      height: getVerticalSize(
                                                        40,
                                                      ),
                                                      width: getSize(
                                                        40,
                                                      ),
                                                      text: "lbl_2".tr,
                                                      margin: getMargin(
                                                        top: 47,
                                                        right: 51,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        width: getHorizontalSize(
                                          119,
                                        ),
                                        margin: getMargin(
                                          left: 3,
                                          top: 38,
                                        ),
                                        child: RichText(
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: "lbl_earth2".tr,
                                                style: TextStyle(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  fontSize: getFontSize(
                                                    45,
                                                  ),
                                                  fontFamily:
                                                      'Arial Rounded MT Bold',
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                              TextSpan(
                                                text: "lbl_planet".tr,
                                                style: TextStyle(
                                                  color:
                                                      ColorConstant.whiteA700,
                                                  fontSize: getFontSize(
                                                    45,
                                                  ),
                                                  fontFamily: 'Abel',
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                            ],
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                      Container(
                                        width: getHorizontalSize(
                                          258,
                                        ),
                                        margin: getMargin(
                                          left: 7,
                                          top: 2,
                                          right: 65,
                                        ),
                                        child: Text(
                                          "msg_stay_ahead_of_the".tr,
                                          maxLines: null,
                                          textAlign: TextAlign.left,
                                          style: AppStyle.txtAbelRegular12,
                                        ),
                                      ),
                                      Padding(
                                        padding: getPadding(
                                          left: 7,
                                          top: 21,
                                        ),
                                        child: Row(
                                          children: [
                                            Text(
                                              "lbl_view_more2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtArialRoundedMTBold15,
                                            ),
                                            CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgArrowright,
                                              height: getVerticalSize(
                                                10,
                                              ),
                                              width: getHorizontalSize(
                                                5,
                                              ),
                                              margin: getMargin(
                                                left: 15,
                                                top: 7,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
