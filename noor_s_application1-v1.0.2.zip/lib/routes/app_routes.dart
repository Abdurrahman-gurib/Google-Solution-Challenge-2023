import 'package:noor_s_application1/presentation/index_screen/index_screen.dart';
import 'package:noor_s_application1/presentation/index_screen/binding/index_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String indexScreen = '/index_screen';

  static String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: indexScreen,
      page: () => IndexScreen(),
      bindings: [
        IndexBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => IndexScreen(),
      bindings: [
        IndexBinding(),
      ],
    )
  ];
}
