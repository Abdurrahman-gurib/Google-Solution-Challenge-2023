import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color whiteA7007f = fromHex('#7fffffff');

  static Color gray700 = fromHex('#575568');

  static Color gray400 = fromHex('#c7c7c7');

  static Color blueGray100 = fromHex('#d7d7d7');

  static Color deepPurple2007f = fromHex('#7fb0afdf');

  static Color blueGray600 = fromHex('#55647d');

  static Color blueGray9007f = fromHex('#7f1f1d39');

  static Color black9000c = fromHex('#0c000000');

  static Color black9003f = fromHex('#3f000000');

  static Color gray100 = fromHex('#f2f7f7');

  static Color whiteA70033 = fromHex('#33ffffff');

  static Color teal300 = fromHex('#3a9fbf');

  static Color black90001 = fromHex('#060425');

  static Color black900 = fromHex('#0a0a14');

  static Color cyan600 = fromHex('#0da1d0');

  static Color whiteA700 = fromHex('#ffffff');

  static Color cyan500 = fromHex('#10bdd5');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
