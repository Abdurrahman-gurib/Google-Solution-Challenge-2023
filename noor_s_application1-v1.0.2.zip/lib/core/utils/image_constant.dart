class ImageConstant {
  static String imgScreenshot2022 = 'assets/images/img_screenshot2022.png';

  static String imgVector3 = 'assets/images/img_vector3.png';

  static String imgPexelspixabay76969 =
      'assets/images/img_pexelspixabay76969.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
