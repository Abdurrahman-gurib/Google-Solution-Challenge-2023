import 'controller/index_controller.dart';
import 'package:flutter/material.dart';
import 'package:noor_s_application1/core/app_export.dart';
import 'package:noor_s_application1/widgets/custom_button.dart';

class IndexScreen extends GetWidget<IndexController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          height: size.height,
          width: double.maxFinite,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  padding: getPadding(
                    left: 40,
                    top: 78,
                    right: 40,
                    bottom: 78,
                  ),
                  decoration: AppDecoration.outlineBlack9000c,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: getHorizontalSize(
                          251,
                        ),
                        margin: getMargin(
                          right: 83,
                        ),
                        child: Text(
                          "msg_earthquake_notifier".tr,
                          maxLines: null,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtArialRoundedMTBold45,
                        ),
                      ),
                      Container(
                        width: getHorizontalSize(
                          262,
                        ),
                        margin: getMargin(
                          top: 37,
                          right: 72,
                          bottom: 501,
                        ),
                        child: Text(
                          "msg_you_can_access_real_time".tr,
                          maxLines: null,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtAbelRegular12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: getVerticalSize(
                    801,
                  ),
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgPexelspixabay76969,
                        height: getVerticalSize(
                          624,
                        ),
                        width: getHorizontalSize(
                          414,
                        ),
                        alignment: Alignment.topCenter,
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          margin: getMargin(
                            bottom: 287,
                          ),
                          decoration: AppDecoration.txtOutlineBlack9003f,
                          child: Text(
                            "msg_app_created_by_noor".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: AppStyle.txtArialRoundedMTBold12,
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: getPadding(
                            left: 40,
                            top: 90,
                          ),
                          child: Text(
                            "lbl_view_more".tr,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.left,
                            style: AppStyle.txtArialRoundedMTBold16,
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgVector3,
                        height: getVerticalSize(
                          383,
                        ),
                        width: getHorizontalSize(
                          414,
                        ),
                        alignment: Alignment.topCenter,
                        margin: getMargin(
                          top: 18,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: getPadding(
                            left: 67,
                            right: 74,
                            bottom: 185,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomButton(
                                height: getVerticalSize(
                                  34,
                                ),
                                width: getHorizontalSize(
                                  105,
                                ),
                                text: "lbl_next".tr,
                                variant: ButtonVariant.FillCyan600,
                                shape: ButtonShape.RoundedBorder6,
                                padding: ButtonPadding.PaddingAll7,
                                fontStyle: ButtonFontStyle.AbelRegular15,
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgScreenshot2022,
                                height: getVerticalSize(
                                  109,
                                ),
                                width: getHorizontalSize(
                                  273,
                                ),
                                margin: getMargin(
                                  top: 26,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
