import 'package:noor_s_application1/core/app_export.dart';
import 'package:noor_s_application1/presentation/index_screen/models/index_model.dart';

class IndexController extends GetxController {
  Rx<IndexModel> indexModelObj = IndexModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
